
#ifndef __AXP2101_TILE_H__
#define __AXP2101_TILE_H__

#include "../lvgl_ui.h"

#ifdef __cplusplus
extern "C" {
#endif

void axp2101_tile_init(lv_obj_t *parent);


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif