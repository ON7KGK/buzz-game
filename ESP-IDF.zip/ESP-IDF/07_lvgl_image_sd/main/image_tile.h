#ifndef __IMAGE_TILE_H__
#define __IMAGE_TILE_H__

#include <stdio.h>
#include <string.h>
#include "lvgl.h"


#ifdef __cplusplus
extern "C" {
#endif

void image_tile_init(lv_obj_t *parent);


#ifdef __cplusplus
}
#endif



#endif