#ifndef __SYSTEM_TILE_H__
#define __SYSTEM_TILE_H__

#include "../lvgl_ui.h"


#ifdef __cplusplus
extern "C" {
#endif

void system_tile_init(lv_obj_t *parent);


#ifdef __cplusplus
}
#endif



#endif