#ifndef __CAMERA_TILE_H__
#define __CAMERA_TILE_H__

#include "../lvgl_ui.h"

#ifdef __cplusplus
extern "C" {
#endif

void camera_tile_init(lv_obj_t *parent);


#ifdef __cplusplus
}
#endif

#endif
