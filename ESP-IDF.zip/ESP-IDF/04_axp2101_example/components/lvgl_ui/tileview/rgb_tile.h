#ifndef __RGB_TILE_H__
#define __RGB_TILE_H__

#include "../lvgl_ui.h"


#ifdef __cplusplus
extern "C" {
#endif

void rgb_tile_init(lv_obj_t *parent);


#ifdef __cplusplus
}
#endif



#endif